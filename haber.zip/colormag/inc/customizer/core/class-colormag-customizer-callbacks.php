<?php
/**
 * ColorMag customizer class for theme customize callbacks.
 *
 * Class ColorMag_Customizer_FrameWork_FrameWork_Callbacks
 *
 * @package    ThemeGrill
 * @subpackage ColorMag
 * @since      ColorMag 3.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ColorMag customizer class for theme customize callbacks.
 *
 * Class ColorMag_Customizer_FrameWork_Callbacks
 */
class ColorMag_Customizer_FrameWork_Callbacks {

}
